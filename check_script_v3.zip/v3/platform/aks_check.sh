#!/bin/bash

# AKS 플랫폼 점검 스크립트 (2차 기술지원용)
# 이 스크립트는 AKS 클러스터의 플랫폼 수준 상세 점검을 수행합니다.

# 환경 변수 파일 로드
source ./aks_check.env

# 기본 값 설정
LOG_DIR="./logs"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG_FILE="${LOG_DIR}/aks_platform_${TIMESTAMP}.log"

# 로그 디렉토리가 없으면 생성
mkdir -p ${LOG_DIR}

# 로그 파일 초기화
echo "=== AKS 플랫폼 상태 점검 보고서 ===" > ${LOG_FILE}
echo "점검 시각: $(date)" >> ${LOG_FILE}
echo "=================================" >> ${LOG_FILE}

# 민감 정보 마스킹 함수
mask_sensitive_info() {
    local content="$1"
    # 마스킹할 패턴 정의
    local patterns=(
        's/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/********-****-****-****-************/gi'  # UUID
        's/[A-Za-z0-9+/]{88,90}=[A-Za-z0-9+/]*={0,2}/************************************/g'  # Base64
        's/"clientId": "[^"]*"/"clientId": "****"/g'
        's/"clientSecret": "[^"]*"/"clientSecret": "****"/g'
        's/"subscriptionId": "[^"]*"/"subscriptionId": "****"/g'
        's/"tenantId": "[^"]*"/"tenantId": "****"/g'
        's/ssh-rsa [A-Za-z0-9+/]+[=]*/ssh-rsa ****/g'  # SSH 키
        's/password[=:][ ]*[^ ]*\b/password: ****/gi'   # 패스워드
        's/secret[=:][ ]*[^ ]*\b/secret: ****/gi'       # 시크릿
        's/token[=:][ ]*[^ ]*\b/token: ****/gi'         # 토큰
        's/key[=:][ ]*[^ ]*\b/key: ****/gi'             # 키
        's/managed-identity-id[=:][ ]*[^ ]*\b/managed-identity-id: ****/gi'  # Managed Identity
        's/principal-id[=:][ ]*[^ ]*\b/principal-id: ****/gi'  # Principal ID
    )
    
    local masked_content="$content"
    for pattern in "${patterns[@]}"; do
        masked_content=$(echo "$masked_content" | sed -E "$pattern")
    done
    echo "$masked_content"
}

# 로그 메시지 출력 함수
log_message() {
    local message="$1"
    local masked_message=$(mask_sensitive_info "$message")
    echo "$masked_message" | tee -a ${LOG_FILE}
}

# 명령어 실행 결과 로깅 함수
log_command() {
    local command="$1"
    local output
    output=$($command 2>&1)
    log_message "$(mask_sensitive_info "$output")"
}

# 클러스터 구성 확인
check_cluster_config() {
    log_message "\n=== 클러스터 구성 확인 ==="
    
    # 클러스터 정보 조회
    local cluster_info=$(az aks show -g ${RESOURCE_GROUP} -n ${CLUSTER_NAME} -o json)
    local masked_info=$(mask_sensitive_info "$cluster_info")
    
    # 쿠버네티스 버전 확인
    local k8s_version=$(echo ${masked_info} | jq -r .kubernetesVersion)
    log_message "쿠버네티스 버전: ${k8s_version}"
    
    # 네트워크 프로필 확인
    local network_plugin=$(echo ${masked_info} | jq -r .networkProfile.networkPlugin)
    local network_policy=$(echo ${masked_info} | jq -r .networkProfile.networkPolicy)
    log_message "네트워크 플러그인: ${network_plugin}"
    log_message "네트워크 정책: ${network_policy}"
    
    # 애드온 확인
    local monitoring_enabled=$(echo ${masked_info} | jq -r .addonProfiles.omsagent.enabled)
    log_message "모니터링 활성화 상태: ${monitoring_enabled}"
}

# 노드풀 확인
check_node_pools() {
    log_message "\n=== 노드풀 상태 확인 ==="
    
    # 노드풀 정보 조회
    log_command "az aks nodepool list -g ${RESOURCE_GROUP} --cluster-name ${CLUSTER_NAME} -o table"
    
    # 자동 스케일링 설정 확인
    for pool in $(az aks nodepool list -g ${RESOURCE_GROUP} --cluster-name ${CLUSTER_NAME} -o json | jq -r .[].name); do
        local pool_info=$(az aks nodepool show -g ${RESOURCE_GROUP} --cluster-name ${CLUSTER_NAME} -n ${pool} -o json)
        local masked_pool_info=$(mask_sensitive_info "$pool_info")
        log_message "\n노드풀: ${pool}"
        log_message "자동 스케일링 활성화: $(echo ${masked_pool_info} | jq -r .enableAutoScaling)"
        log_message "최소 노드 수: $(echo ${masked_pool_info} | jq -r .minCount)"
        log_message "최대 노드 수: $(echo ${masked_pool_info} | jq -r .maxCount)"
    done
}

# 네트워크 연결성 확인
check_network() {
    log_message "\n=== 네트워크 연결성 확인 ==="
    
    # DNS 해석 테스트
    log_message "DNS 해석 테스트 중..."
    log_command "kubectl run -it --rm --restart=Never --image=mcr.microsoft.com/aks/fundamental/base-ubuntu:v0.0.11 dns-test -- nslookup kubernetes.default"
    
    # 네트워크 정책 확인
    if kubectl get networkpolicies --all-namespaces &> /dev/null; then
        log_message "네트워크 정책 목록:"
        log_command "kubectl get networkpolicies --all-namespaces"
    else
        log_message "네트워크 정책이 설정되어 있지 않습니다"
    fi
}

# 스토리지 구성 확인
check_storage() {
    log_message "\n=== 스토리지 구성 확인 ==="
    
    # 스토리지 클래스 확인
    log_message "스토리지 클래스:"
    log_command "kubectl get storageclass"
    
    # PVC 확인
    log_message "\n영구 볼륨 클레임(PVC):"
    log_command "kubectl get pvc --all-namespaces"
}

# 클러스터 메트릭 확인
check_metrics() {
    log_message "\n=== 클러스터 메트릭 확인 ==="
    
    # 노드 리소스 사용량
    log_message "노드 리소스 사용량:"
    log_command "kubectl top nodes"
    
    # 파드 리소스 사용량
    log_message "\n파드 리소스 사용량 (상위 10개):"
    log_command "kubectl top pods --all-namespaces | sort -k4 -nr | head -10"
}

# 보안 설정 확인
check_security() {
    log_message "\n=== 보안 설정 확인 ==="
    
    # RBAC 설정 확인
    log_message "RBAC 설정:"
    log_command "kubectl get clusterroles"
    log_command "kubectl get clusterrolebindings"
    
    # Pod Security Policy 확인
    if kubectl get psp &> /dev/null; then
        log_message "\nPod Security Policy:"
        log_command "kubectl get psp"
    else
        log_message "\nPod Security Policy가 설정되어 있지 않습니다"
    fi
}

# 로깅 및 모니터링 확인
check_monitoring() {
    log_message "\n=== 로깅 및 모니터링 확인 ==="
    
    # 진단 설정 확인
    if az monitor diagnostic-settings list --resource ${CLUSTER_NAME} --resource-group ${RESOURCE_GROUP} --resource-type Microsoft.ContainerService/managedClusters -o json &> /dev/null; then
        log_message "진단 설정이 구성되어 있습니다"
        local settings=$(az monitor diagnostic-settings list --resource ${CLUSTER_NAME} --resource-group ${RESOURCE_GROUP} --resource-type Microsoft.ContainerService/managedClusters -o json)
        log_message "$(mask_sensitive_info "$settings")"
    else
        log_message "경고: 진단 설정이 구성되어 있지 않습니다"
    fi
    
    # Prometheus 메트릭 확인
    if kubectl get servicemonitors --all-namespaces &> /dev/null; then
        log_message "ServiceMonitor 목록:"
        log_command "kubectl get servicemonitors --all-namespaces"
    else
        log_message "ServiceMonitor가 설정되어 있지 않습니다"
    fi
}

# 메인 실행
main() {
    check_cluster_config
    check_node_pools
    check_network
    check_storage
    check_metrics
    check_security
    check_monitoring
    
    log_message "\n=== 플랫폼 상태 점검 완료 ==="
    log_message "상세 결과는 다음 파일에서 확인할 수 있습니다: ${LOG_FILE}"
}

main 