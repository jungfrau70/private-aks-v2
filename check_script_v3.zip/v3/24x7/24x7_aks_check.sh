#!/bin/bash

# AKS 24x7 점검 스크립트 (1차 기술지원용)
# 이 스크립트는 AKS 클러스터의 기본적인 상태를 점검합니다.

# 환경 변수 파일 로드
source ./24x7_aks_check.env

# 기본 값 설정
LOG_DIR="./logs"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG_FILE="${LOG_DIR}/24x7_aks_${TIMESTAMP}.log"

# 로그 디렉토리가 없으면 생성
mkdir -p ${LOG_DIR}

# 로그 파일 초기화
echo "=== AKS 24x7 상태 점검 보고서 ===" > ${LOG_FILE}
echo "점검 시각: $(date)" >> ${LOG_FILE}
echo "=================================" >> ${LOG_FILE}

# 민감 정보 마스킹 함수
mask_sensitive_info() {
    local content="$1"
    # 마스킹할 패턴 정의
    local patterns=(
        's/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/********-****-****-****-************/gi'  # UUID
        's/[A-Za-z0-9+/]{88,90}=[A-Za-z0-9+/]*={0,2}/************************************/g'  # Base64
        's/"clientId": "[^"]*"/"clientId": "****"/g'
        's/"clientSecret": "[^"]*"/"clientSecret": "****"/g'
        's/"subscriptionId": "[^"]*"/"subscriptionId": "****"/g'
        's/"tenantId": "[^"]*"/"tenantId": "****"/g'
        's/ssh-rsa [A-Za-z0-9+/]+[=]*/ssh-rsa ****/g'  # SSH 키
        's/password[=:][ ]*[^ ]*\b/password: ****/gi'   # 패스워드
        's/secret[=:][ ]*[^ ]*\b/secret: ****/gi'       # 시크릿
        's/token[=:][ ]*[^ ]*\b/token: ****/gi'         # 토큰
        's/key[=:][ ]*[^ ]*\b/key: ****/gi'             # 키
    )
    
    local masked_content="$content"
    for pattern in "${patterns[@]}"; do
        masked_content=$(echo "$masked_content" | sed -E "$pattern")
    done
    echo "$masked_content"
}

# 로그 메시지 출력 함수
log_message() {
    local message="$1"
    local masked_message=$(mask_sensitive_info "$message")
    echo "$masked_message" | tee -a ${LOG_FILE}
}

# 명령어 실행 결과 로깅 함수
log_command() {
    local command="$1"
    local output
    output=$($command 2>&1)
    log_message "$(mask_sensitive_info "$output")"
}

# 필수 도구 설치 여부 확인
check_prerequisites() {
    log_message "\n=== 필수 도구 설치 여부 확인 ==="
    for tool in az kubectl jq; do
        if ! command -v $tool &> /dev/null; then
            log_message "오류: $tool이 설치되어 있지 않습니다"
            exit 1
        fi
    done
    log_message "모든 필수 도구가 설치되어 있습니다"
}

# Azure 로그인 상태 확인
check_azure_login() {
    log_message "\n=== Azure 로그인 상태 확인 ==="
    if ! az account show &> /dev/null; then
        log_message "오류: Azure에 로그인되어 있지 않습니다. 'az login' 명령어를 실행해주세요"
        exit 1
    fi
    log_message "Azure에 정상적으로 로그인되어 있습니다"
}

# AKS 클러스터 상태 확인
check_aks_status() {
    log_message "\n=== AKS 클러스터 상태 확인 ==="
    local cluster_status=$(az aks show -g ${RESOURCE_GROUP} -n ${CLUSTER_NAME} -o json)
    
    # 클러스터 존재 여부 확인
    if [ $? -ne 0 ]; then
        log_message "오류: 클러스터 상태 확인 실패"
        return 1
    fi

    # 클러스터 상태 마스킹 및 로깅
    local masked_status=$(mask_sensitive_info "$cluster_status")
    
    # 프로비저닝 상태 확인
    local provisioning_state=$(echo ${masked_status} | jq -r .provisioningState)
    log_message "클러스터 프로비저닝 상태: ${provisioning_state}"

    # 전원 상태 확인
    local power_state=$(echo ${masked_status} | jq -r .powerState.code)
    log_message "클러스터 전원 상태: ${power_state}"
}

# 노드 상태 확인
check_node_status() {
    log_message "\n=== 노드 상태 확인 ==="
    log_command "kubectl get nodes -o wide"
    
    # NotReady 노드 확인
    local not_ready_nodes=$(kubectl get nodes | grep -c "NotReady")
    if [ ${not_ready_nodes} -gt 0 ]; then
        log_message "경고: ${not_ready_nodes}개의 노드가 NotReady 상태입니다"
    else
        log_message "모든 노드가 정상 상태입니다"
    fi
}

# 파드 상태 확인
check_pod_status() {
    log_message "\n=== 파드 상태 확인 ==="
    log_command "kubectl get pods --all-namespaces | grep -v 'Running\|Completed'"
    
    # 문제가 있는 파드 확인
    local problem_pods=$(kubectl get pods --all-namespaces | grep -v "Running\|Completed" | wc -l)
    if [ ${problem_pods} -gt 1 ]; then  # 헤더 라인 고려
        log_message "경고: $(($problem_pods-1))개의 파드가 비정상 상태입니다"
    else
        log_message "모든 파드가 정상 실행 중입니다"
    fi
}

# 시스템 서비스 확인
check_system_services() {
    log_message "\n=== 시스템 서비스 상태 확인 ==="
    log_command "kubectl get pods -n kube-system"
}

# 메인 실행
main() {
    check_prerequisites
    check_azure_login
    check_aks_status
    check_node_status
    check_pod_status
    check_system_services
    
    log_message "\n=== 상태 점검 완료 ==="
    log_message "상세 결과는 다음 파일에서 확인할 수 있습니다: ${LOG_FILE}"
}

main 