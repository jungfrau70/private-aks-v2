#!/bin/bash

# AKS 파드 점검 스크립트 (2차 기술지원용)
# 이 스크립트는 AKS 클러스터의 파드 수준 상세 점검을 수행합니다.

# 환경 변수 파일 로드
source ./aks_pod.env

# 기본 값 설정
LOG_DIR="./logs"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG_FILE="${LOG_DIR}/aks_pod_${TIMESTAMP}.log"

# 로그 디렉토리가 없으면 생성
mkdir -p ${LOG_DIR}

# 로그 파일 초기화
echo "=== AKS 파드 상태 점검 보고서 ===" > ${LOG_FILE}
echo "점검 시각: $(date)" >> ${LOG_FILE}
echo "=================================" >> ${LOG_FILE}

# 민감 정보 마스킹 함수
mask_sensitive_info() {
    local content="$1"
    # 마스킹할 패턴 정의
    local patterns=(
        's/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/********-****-****-****-************/gi'  # UUID
        's/[A-Za-z0-9+/]{88,90}=[A-Za-z0-9+/]*={0,2}/************************************/g'  # Base64
        's/"clientId": "[^"]*"/"clientId": "****"/g'
        's/"clientSecret": "[^"]*"/"clientSecret": "****"/g'
        's/"subscriptionId": "[^"]*"/"subscriptionId": "****"/g'
        's/"tenantId": "[^"]*"/"tenantId": "****"/g'
        's/ssh-rsa [A-Za-z0-9+/]+[=]*/ssh-rsa ****/g'  # SSH 키
        's/password[=:][ ]*[^ ]*\b/password: ****/gi'   # 패스워드
        's/secret[=:][ ]*[^ ]*\b/secret: ****/gi'       # 시크릿
        's/token[=:][ ]*[^ ]*\b/token: ****/gi'         # 토큰
        's/key[=:][ ]*[^ ]*\b/key: ****/gi'             # 키
        's/managed-identity-id[=:][ ]*[^ ]*\b/managed-identity-id: ****/gi'  # Managed Identity
        's/principal-id[=:][ ]*[^ ]*\b/principal-id: ****/gi'  # Principal ID
        's/connection[=:][ ]*[^ ]*\b/connection: ****/gi'  # Connection strings
        's/bearer [^ ]*\b/bearer ****/gi'  # Bearer tokens
    )
    
    local masked_content="$content"
    for pattern in "${patterns[@]}"; do
        masked_content=$(echo "$masked_content" | sed -E "$pattern")
    done
    echo "$masked_content"
}

# 로그 메시지 출력 함수
log_message() {
    local message="$1"
    local masked_message=$(mask_sensitive_info "$message")
    echo "$masked_message" | tee -a ${LOG_FILE}
}

# 명령어 실행 결과 로깅 함수
log_command() {
    local command="$1"
    local output
    output=$($command 2>&1)
    log_message "$(mask_sensitive_info "$output")"
}

# 특정 네임스페이스의 파드 상태 확인
check_pod_status() {
    local namespace=$1
    log_message "\n=== 네임스페이스 파드 상태 확인: ${namespace} ==="
    
    # 네임스페이스의 모든 파드 조회
    log_command "kubectl get pods -n ${namespace} -o wide"
    
    # 문제가 있는 파드 확인
    local problem_pods=$(kubectl get pods -n ${namespace} | grep -v "Running\|Completed" | wc -l)
    if [ ${problem_pods} -gt 1 ]; then  # 헤더 라인 고려
        log_message "경고: $(($problem_pods-1))개의 파드가 비정상 상태입니다"
        
        # 문제가 있는 파드 상세 정보 확인
        log_message "\n문제가 있는 파드 상세 정보:"
        kubectl get pods -n ${namespace} | grep -v "Running\|Completed" | tail -n +2 | while read pod; do
            pod_name=$(echo ${pod} | awk '{print $1}')
            log_message "\n파드: ${pod_name}"
            log_command "kubectl describe pod ${pod_name} -n ${namespace}"
            log_message "\n파드 로그:"
            log_command "kubectl logs ${pod_name} -n ${namespace} --tail=50"
        done
    else
        log_message "모든 파드가 정상 실행 중입니다"
    fi
}

# 파드 리소스 사용량 확인
check_pod_resources() {
    local namespace=$1
    log_message "\n=== 파드 리소스 사용량 확인: ${namespace} ==="
    
    # 리소스 사용량 조회
    log_command "kubectl top pods -n ${namespace}"
    
    # 리소스 제한 설정 확인
    kubectl get pods -n ${namespace} -o json | jq -r '.items[] | select(.spec.containers[].resources.limits) | .metadata.name' | while read pod; do
        log_message "\n파드 리소스 제한 확인: ${pod}"
        log_command "kubectl describe pod ${pod} -n ${namespace} | grep -A 3 'Limits:'"
    done
}

# 파드 네트워킹 확인
check_pod_networking() {
    local namespace=$1
    log_message "\n=== 파드 네트워킹 확인: ${namespace} ==="
    
    # 서비스 확인
    log_message "서비스 목록:"
    log_command "kubectl get services -n ${namespace}"
    
    # 엔드포인트 확인
    log_message "\n엔드포인트 목록:"
    log_command "kubectl get endpoints -n ${namespace}"
    
    # 네트워크 정책 확인
    if kubectl get networkpolicies -n ${namespace} &> /dev/null; then
        log_message "\n네트워크 정책 목록:"
        log_command "kubectl get networkpolicies -n ${namespace}"
    fi
}

# 파드 볼륨 확인
check_pod_volumes() {
    local namespace=$1
    log_message "\n=== 파드 볼륨 확인: ${namespace} ==="
    
    # PVC 확인
    log_message "영구 볼륨 클레임(PVC) 목록:"
    log_command "kubectl get pvc -n ${namespace}"
    
    # 파드 볼륨 마운트 확인
    log_message "\n파드 볼륨 마운트 정보:"
    kubectl get pods -n ${namespace} -o json | jq -r '.items[] | select(.spec.volumes) | .metadata.name' | while read pod; do
        log_message "\n파드 볼륨 마운트: ${pod}"
        log_command "kubectl describe pod ${pod} -n ${namespace} | grep -A 5 'Volumes:'"
    done
}

# 파드 로그 확인
check_pod_logs() {
    local namespace=$1
    log_message "\n=== 파드 로그 확인: ${namespace} ==="
    
    # 모든 파드의 로그 확인
    kubectl get pods -n ${namespace} -o name | while read pod; do
        pod_name=$(echo ${pod} | cut -d'/' -f2)
        log_message "\n파드 로그: ${pod_name}"
        log_message "최근 50줄의 로그:"
        log_command "kubectl logs ${pod_name} -n ${namespace} --tail=50"
        
        # 에러 패턴 확인
        log_message "\n로그에서 에러 확인:"
        log_command "kubectl logs ${pod_name} -n ${namespace} | grep -i 'error\|exception\|failed'"
    done
}

# 파드 이벤트 확인
check_pod_events() {
    local namespace=$1
    log_message "\n=== 파드 이벤트 확인: ${namespace} ==="
    
    # 시간순 정렬된 이벤트 조회
    log_command "kubectl get events -n ${namespace} --sort-by='.metadata.creationTimestamp'"
}

# 파드 구성 확인
check_pod_config() {
    local namespace=$1
    log_message "\n=== 파드 구성 확인: ${namespace} ==="
    
    # 디플로이먼트 확인
    log_message "디플로이먼트 목록:"
    log_command "kubectl get deployments -n ${namespace}"
    
    # 레플리카셋 확인
    log_message "\n레플리카셋 목록:"
    log_command "kubectl get rs -n ${namespace}"
    
    # 컨피그맵 확인
    log_message "\n컨피그맵 목록:"
    log_command "kubectl get configmaps -n ${namespace}"
    
    # 시크릿 확인 (마스킹 처리)
    log_message "\n시크릿 목록:"
    local secrets_output=$(kubectl get secrets -n ${namespace} 2>&1)
    log_message "$(mask_sensitive_info "$secrets_output")"
}

# 메인 실행
main() {
    # 특정 네임스페이스가 지정된 경우
    if [ ! -z "${NAMESPACE}" ]; then
        check_pod_status ${NAMESPACE}
        check_pod_resources ${NAMESPACE}
        check_pod_networking ${NAMESPACE}
        check_pod_volumes ${NAMESPACE}
        check_pod_logs ${NAMESPACE}
        check_pod_events ${NAMESPACE}
        check_pod_config ${NAMESPACE}
    else
        # 모든 네임스페이스 확인
        for ns in $(kubectl get namespaces -o jsonpath='{.items[*].metadata.name}'); do
            check_pod_status ${ns}
            check_pod_resources ${ns}
            check_pod_networking ${ns}
            check_pod_volumes ${ns}
            check_pod_logs ${ns}
            check_pod_events ${ns}
            check_pod_config ${ns}
        done
    fi
    
    log_message "\n=== 파드 상태 점검 완료 ==="
    log_message "상세 결과는 다음 파일에서 확인할 수 있습니다: ${LOG_FILE}"
}

main 