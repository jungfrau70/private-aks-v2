#!/bin/bash

# 24x7 AKS 긴급점검 스크립트 (1st level technical support)
# 작성일: $(date '+%Y-%m-%d')

# 환경변수 파일 로드
if [ -f "24x7_aks_check.env" ]; then
    source 24x7_aks_check.env
else
    echo "Error: 24x7_aks_check.env 파일이 없습니다."
    exit 1
fi

# 로그 디렉토리 생성
LOG_DIR="24x7_aks_logs"
mkdir -p $LOG_DIR

# 로그 파일명 설정
TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
LOG_FILE="$LOG_DIR/24x7_aks_${TIMESTAMP}.log"

# 로그 함수
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a $LOG_FILE
}

# AKS 클러스터 상태 체크
check_aks_status() {
    log "=== AKS 클러스터 상태 체크 ==="
    az aks show --name $AKS_CLUSTER_NAME --resource-group $RESOURCE_GROUP --query "provisioningState" -o tsv >> $LOG_FILE 2>&1
    az aks show --name $AKS_CLUSTER_NAME --resource-group $RESOURCE_GROUP --query "powerState.code" -o tsv >> $LOG_FILE 2>&1
}

# 노드 상태 체크
check_node_status() {
    log "=== 노드 상태 체크 ==="
    kubectl get nodes -o wide >> $LOG_FILE 2>&1
}

# Pod 상태 체크
check_pod_status() {
    log "=== Pod 상태 체크 ==="
    kubectl get pods --all-namespaces -o wide >> $LOG_FILE 2>&1
}

# 시스템 Pod 상태 체크
check_system_pods() {
    log "=== 시스템 Pod 상태 체크 ==="
    kubectl get pods -n kube-system >> $LOG_FILE 2>&1
}

# 네트워크 상태 체크
check_network_status() {
    log "=== 네트워크 상태 체크 ==="
    kubectl get services --all-namespaces >> $LOG_FILE 2>&1
    kubectl get ingress --all-namespaces >> $LOG_FILE 2>&1
}

# 메인 실행
main() {
    log "24x7 AKS 긴급점검 시작"
    
    # Azure 로그인 체크
    if ! az account show &> /dev/null; then
        log "Error: Azure에 로그인되어 있지 않습니다. 'az login' 명령어로 로그인하세요."
        exit 1
    fi

    # Kubernetes 컨텍스트 체크
    if ! kubectl cluster-info &> /dev/null; then
        log "Error: Kubernetes 클러스터에 연결할 수 없습니다."
        exit 1
    fi

    # 각 체크 함수 실행
    check_aks_status
    check_node_status
    check_pod_status
    check_system_pods
    check_network_status

    log "24x7 AKS 긴급점검 완료"
    log "로그 파일 위치: $LOG_FILE"
}

# 스크립트 실행
main 